from smtplib import SMTP_SSL as SMTP
from email.mime.text import MIMEText
import re

class mail:
    def login(pwd='',user='vivekchaudhary@iitkgp.ac.in', server='iitkgpmail.iitkgp.ac.in'):
        server = SMTP(server)
        #server.set_debuglevel(True)
        try:
            server.login(user, pwd)
            return server
        except:
            print("Authintication failed.")
            return "Server Authintication failed."
    
    def send_mail(server, subject='', message='', to='' , From=''):
        if len(re.findall(r'.*@.*\..*',to))==0:
            print ("Invalid reciepient email-address")
            return
        elif len(re.findall(r'.*@.*\..*',From))==0:
            print("Invalid sender email-address")
            return
        msg = MIMEText(message, 'plain')
        msg['Subject'] = subject
        msg['To']=to
        server.sendmail(From, to, msg.as_string())

def PostMan(to, subject, message):
    try:
        server = mail.login("mrsherlocKholmes")
        mail.send_mail(server, subject, message, to, 'EMGL@iitkgp.ac.in')
        print("Email dispatched!")
    except: print("Mail not sent!")

