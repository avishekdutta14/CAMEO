def otu_table(otu_file, taxa_file, fasta_file, controls):
    def make_dictionary(taxa_file):
        print("Reading Taxa file... Please wait...")
        taxa_dict={}
        try:
            with open(taxa_file) as f:
                for line in f:
                    try:
                        line=line.strip('\n').split('\t')
                        taxa_dict[line[0]]=line[1]
                    except: pass
            return taxa_dict,True
        except: print('ERROR: %s TAXA_FILE not found'%taxa_file)
        return taxa_dict,False

    def read_fasta(fasta_file):
        print("Reading FASTA file... Please wait...")
        fasta_dict = {}
        try:
            with open(fasta_file) as f: data = f.readlines()
            for r in range(0, len(data), 2):
                fasta_dict[data[r].split(' ')[0].strip('>')] = data[r+1].strip('\n')
            return fasta_dict
        except: print("%s FASTA file NOT FOUND"%(fasta_file))
        return False
    
    def parse_otu(otu_file, controls=[]):
        try: controls.remove('')
        except: pass
        print("Reading OTU file... Please wait...")
        stack,cols=[],[]
        try:
            with open(otu_file) as f:
                for denovo in f:
                    denovo=denovo.strip('\n').split('\t')
                    counter=[denovo[0]]+['0']*len(cols)
                    for r in range(1,len(denovo)): denovo[r]=denovo[r].split('_')[0]
                    SET=set(denovo)
                    if any(sample in SET for sample in controls): continue
                    SET.remove(denovo[0])
                    for d in list(SET):
                        if d not in cols:
                            cols.append(d)
                            counter.append(str(denovo.count(d)))
                        else: counter[cols.index(d)+1] = str(denovo.count(d))                      
                    stack.append(counter)
            return stack,cols,True
        except Exception as e: print('ERROR: %s OTU_FILE not found'%otu_file, e, e.__doc__)
        return stack,cols,False

    def dump(stack, taxa_dict, cols, fasta_dict):
        print("Writing data in otu_table.csv... Please wait...")
        GC = lambda seq : [seq, str((seq.count('G')+seq.count('C'))*100/len(seq))]
        try:
            with open("otu_table.csv",'w') as f:
                if fasta_dict:
                    f.write('#OTU ID,'+','.join(cols)+',Taxa,Seq,GC\n')
                    for x in stack: f.write(','.join( x + ['0']*(len(cols)-len(x)+1) + [taxa_dict[x[0]]] + GC(fasta_dict[x[0]]))+'\n')
                else:
                    f.write('#OTU ID,'+','.join(cols)+',Taxa\n')
                    for x in stack: f.write(','.join(x+['0']*(len(cols)-len(x)+1)+[taxa_dict[x[0]]])+'\n')
            return True
        except Exception as e: print("Some Error while writing data in .csv file\n%s\n%s"%(e,e.__doc__))
        return False
    
    try:
        stack, cols, status = parse_otu(otu_file, controls.split(','))
        taxa_dict = fasta_dict = False
        if status and taxa_file: taxa_dict,status = make_dictionary(taxa_file)
        if status: fasta_dict = read_fasta(fasta_file)
        if status: status = dump(stack, taxa_dict, cols, fasta_dict)
        if status: print("Process completed successfully.")
        else: print("Process terminated before completion")
    except: print("Process terminated before completion")
    return "otu_table.csv"

if __name__=='__main__':
    with open("index.txt") as f: index = f.readlines()
    index = dict(line.strip('\n').split(' : ') for line in index)
    otu_table(index['OTU'], index['TAXA'], index['FASTA'], index['CONTROL'])
    input("\nPress <ENTER> to exit.")
