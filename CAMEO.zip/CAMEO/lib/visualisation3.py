def cluster(otu_file):
    def read(otu_file):
        print("Reading OTU table. Please wait...")
        stack=[]
        max_taxa_len=0
        with open(otu_file) as f: data = f.readlines()
        taxa_loc = data[0].strip('\n').split(',').index('Taxa')+1
        for line in data:
            stack.append(line.strip('\n').split(',')[:taxa_loc])
            taxa_len=len(line.split(";"))
            if taxa_len>max_taxa_len: max_taxa_len=taxa_len
        return stack[0][1:-1],max_taxa_len,stack[1:]

    def condense(stack,max_taxa_len):
        taxa_cols=[{}]
        total=len(stack)
        temp = m =0
        markers = ['|','/','-','\\']
        for r,denovo in enumerate(stack):
            completed=(r+1)*100//total
            if completed > temp:
                temp=completed
                m = (m+1)%4
                print("\rComputing... Please wait... %s [%d%%]"%(markers[m], completed),end='')
            taxa_opts=denovo[-1].split(';')
            taxa_opts+=['']*(max_taxa_len-len(taxa_opts))
            for r in range(len(taxa_opts)):
                taxa=';'.join(taxa_opts[:r+1])
                try:
                    taxas=taxa_cols[r]
                    try: taxas[taxa]=[str(int(SUM)+int(new)) for SUM,new in zip(taxas[taxa],denovo[1:-1])]
                    except: taxas[taxa]=denovo[1:-1]
                except:
                    taxa_cols.append({})
                    taxas=taxa_cols[r]
                    try: taxas[taxa]=[int(SUM)+int(new) for SUM,new in zip(taxas[taxa],denovo[1:-1])]
                    except: taxas[taxa]=denovo[1:-1]
        print('')
        return taxa_cols

    names,max_taxa_len,stack=read(otu_file)
    taxa_cols=condense(stack,max_taxa_len)
    return taxa_cols,names

def write_html(data,names, output_name):
    def make_node(name,value):
        return '''<node name="%s"><magnitude><val> %s</val></magnitude>\n'''%(name,value)

    def close_node():
        return '''</node>\n'''

    def recursive_fn(data,base,level,r):
        for key in sorted(data[0]):
            value=data[0][key][r]
            if value=='0':
                continue
            key_for_comparision = ';'.join(key.split(';')[:level+1])
            next_level_key = key.split(';')[level+1]
            if next_level_key == '':
                continue
            if key_for_comparision == base:
                f.write(make_node(next_level_key , value))
                try:
                    recursive_fn(data[1:],key,level+1,r)
                except:
                    pass
                f.write(close_node())
                
    def main(data,names):
        R=len(names)
        f.write(make_node("OTUs",sum(sum(int(x[r]) for x in data[0].values()) for r in range(R))))
        for r in range(R):
            print("\rCreating visualization file. Please wait... [%d%%]"%(r*100//R),end='')
            f.write(make_node(names[r],sum(int(x[r]) for x in data[0].values())))
            total=len(data[0])
            marker=1
            for key in sorted(data[0]):
                value=data[0][key][r]
                if key=='': continue
                f.write(make_node(key,value))
                recursive_fn(data[1:],key,0,r)
                f.write(close_node())
                marker+=1
            f.write(close_node())
        print("\rDynamic visualization completed.                      ")
        f.write(close_node())

    HTML="""<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xml:lang="en" lang="en">
        <head>
            <meta charset="utf-8"/>
            <script id="notfound">window.onload=function(){document.body.innerHTML="Could not get resources from /Files/Java_Script.txt."}</script>
            <script src="./Files/Java_Script.txt"></script>
        </head>
        <body>
            <img id="hiddenImage" src="./Files/hidden.png"  style="display:none"/>
            <noscript>Javascript must be enabled to view this page.</noscript>
            <div style="display:none">
                    <krona>
                            <attributes magnitude="magnitude">
                                    <attribute display="Total OTUs">magnitude</attribute>
                            </attributes>\n"""
    XHTML="""\n</krona></div></body></html>"""
    with open(output_name,'w') as f:
        f.write(HTML)
        main(data,names)
        f.write(XHTML)

def splitter(taxa_cols,names):
    def dump(taxa_cols,names):
        print("Writing new files. Please wait...")
        for r, taxa_col in enumerate(taxa_cols):
            with open('D_%d.csv'%r,'w') as f:
                f.write(','.join(['#Taxa']+names)+'\n')
                for p in sorted(taxa_col):
                    f.write(','.join([p]+taxa_col[p]).replace(',0',',')+'\n')
        return r

    def analyze(data, names, file_no):
        pointer = 0
        col_length = names.count(',')
        with open("DC_%d.csv"%file_no,'w') as f:
            f.write(names)
            while pointer < len(data)-1:
                if data[pointer][0] == data[pointer+1][0]:
                    for r in range(1, col_length+1): data[pointer+1][r] += data[pointer][r]
                else:
                    if data[pointer][0] == '': data[pointer][0] = 'Unassigned'
                    f.write(','.join(map(str,data[pointer]))+'\n')
                pointer+=1

    def counter(R):
        for r in range(1,R+1):
            with open('D_%d.csv'%r) as f: data = f.readlines()
            names, data, stack = data[0], data[1:], []
            for line in data:
                line = line.strip('\n').split(',')
                line[0] = line[0].split(';')[-1].strip(' ')
                for x in range(1,len(line)): line[x] = min(1, int(line[x].replace('','0')))
                stack.append(line)
            analyze(sorted(stack), names, r)
    r = dump(taxa_cols,names)
    counter(r)

def visualize(otu_table, output_name = "visualisation.html", split_in_files = False):
     data,names=cluster(otu_table)
     if split_in_files: splitter(data, names)
     write_html(data, names, output_name)

if __name__=='__main__':
    visualize('unique_otu_table.csv', 'xxx.html', 'True')
    input("\n\nCompleted...")
