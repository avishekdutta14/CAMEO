def compare(otu_table, compare_sets):
    try:
        with open(otu_table) as f: lines = f.readlines()
        columns = lines[0].strip('\n').split(',')
        taxa_col = columns.index('Taxa')
        for compare in compare_sets.split(';'):
            print("Building Comparision Table for %s"%compare.strip('\n'))
            cols_of_interest = [columns.index(x) for x in columns if x in compare.strip('\n').split(',')]
            all_cols = [0] + cols_of_interest + list(range(taxa_col, len(columns)))
            name_of_table = "comparision_table_%s.csv" % compare.strip('\n').replace(',','_')
            with open(name_of_table, 'w') as f:
                f.write(','.join([columns[r] for r in all_cols])+'\n')
                for line in lines[1:]:
                    line = line.strip('\n').split(',')
                    if all(val!='0' for val in [line[r] for r in cols_of_interest]):
                        f.write(','.join([line[r] for r in all_cols]) + '\n')
        print("Comparision Table complete.")
        return name_of_table
    except Exception as e: print(e)

if __name__=='__main__':
    with open("index.txt") as f: index = f.readlines()
    index = dict(line.strip('\n').split(' : ') for line in index)
    name = compare("otu_table.csv", index['COMPARE'])
    #input("\nPress <ENTER> to exit.")
