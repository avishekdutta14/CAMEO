from random import sample, choice

def rarefaction(otu_file,step):
    def read_file(otu_file):
        print("Attempting Rarefaction...")
        try:
            stack=[]
            with open(otu_file) as f: data = f.readlines()
            names = data[0].strip('\n').split(',')
            try: samples = names.index('Taxa')
            except: samples = len(names)
            names = names[1:samples]
            for x in range(samples): stack.append([])
            for line in data[1:]:
                line=line.strip('\n').split(',')[1:samples]
                try:
                    for x in range(samples): stack[x].append(int(float(line[x].strip(' '))))
                except: pass
            x_lim,x_min=0,10**10
            for x in stack:
                if len(x)==0:
                    stack.remove(x)
                    continue
                n=sum(x)
                if n>x_lim: x_lim=n
                if n<x_min: x_min=n
            print("Minimum clusters: %d || Maximum clusters: %d"%(x_min,x_lim))
        except: print("Make sure there is a %s file present in the folder."%file)
        return stack,names,x_lim
    
    def SAMPLE(population,depth):
        p=[]
        l,marker=[],0
        for no in population:
            l+=[marker]*no
            marker+=1
        for x in range(1): p.append(len(set(sample(l,depth))))
        return sum(p)/len(p)

    def rarefy(stack, step, limit):
        def bootstrap(population, step):
            individuals = []
            for indi, indi_count in enumerate(population): individuals += [indi]*indi_count
            y=[]
            x_lim = len(individuals)
            for sample_size in range(1, x_lim, step):
                p = []
                try:
                    for precision in range(1): p.append(len(set(sample(individuals, sample_size))))
                    y.append(sum(p)/len(p))
                except: y.append('')
            return y
            
        try:
            x_axis = list(range(1, limit+1, step))
            y_axes = []
            tot_cols = len(stack)
            print('\rPlotting Rarefaction curves... [0.00%] completed', end='')
            for i, column in enumerate(stack):
                y_axes.append(bootstrap(column, step))
                print('\rPlotting Rarefaction curves... [%.2f%%] completed  '%((i+1)*100/(tot_cols)),end='')
        except Exception as e:
            print(e, e.__doc__)
            print("\n\nSOMETHING UNFORESEEN HAPPENED. Script will exit.")
            return 0,0,False
        return x_axis, y_axes, True
    
    def dump(names,x,y):
        try:
            with open("rarefaction_data.csv",'w') as f:
                f.write('Sample Size,'+','.join(names)+'\n')
                for p in range(len(x)):
                    line=str(x[p])+','
                    for yi in y:
                        try: line+=str(yi[p])+','
                        except: line+=','
                    line=line.strip(',')+'\n'
                    f.write(line)
            return True
        except: return False
        
    stack, names, x_lim = read_file(otu_file)
    status=False
    if x_lim: x, ys, status = rarefy(stack, step, x_lim)
    if status: status = dump(names,x,ys)
    if status:
        print("\nCurve data dumped into rarefaction_data.csv, use Excel to plot the curve!")
        return 'rarefaction_data.csv'
    return False
    

if __name__=='__main__':
    name = rarefaction('unique_otu_table.csv', 500)
    input("\nPress <ENTER> to exit.")
