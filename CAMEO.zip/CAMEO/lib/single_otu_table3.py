def single_otu_table(otu_file, taxa_file, fasta_file):
    def make_dictionary(taxa_file):
        print("Reading Taxa file... Please wait...")
        taxa_dict={}
        try:
            with open(taxa_file) as f:
                for line in f:
                    try:
                        line=line.strip('\n').split('\t')
                        taxa_dict[line[0]]=line[1]
                    except: pass
            return taxa_dict,True
        except: print('ERROR: %s TAXA_FILE not found'%taxa_file)
        return taxa_dict,False
    
    def parse_otu(otu_file):
        print("Reading OTU file... Please wait...")
        stack,cols=[],[]
        try:
            with open(otu_file) as f:
                for denovo in f:
                    denovo=denovo.strip('\n').split('\t')
                    for r in range(1,len(denovo)): denovo[r]=denovo[r].split('_')[0]
                    if len(set(denovo))==2:
                        denovo=denovo[:2]+[len(denovo)-1]
                        stack.append(denovo)
                        if denovo[1] not in cols: cols.append(denovo[1])
            return stack,cols,True
        except: print('ERROR: %s OTU_FILE not found'%otu_file)
        return stack,cols,False

    def read_fasta(fasta_file):
        print("Reading FASTA file... Please wait...")
        fasta_dict = {}
        try:
            with open(fasta_file) as f: data = f.readlines()
            for r in range(0, len(data), 2):
                fasta_dict[data[r].split(' ')[0].strip('>')] = data[r+1].strip('\n')
            return fasta_dict
        except: print("%s FASTA file NOT FOUND"%(fasta_file))
        return False

    def dump(stack, taxa_dict, cols, fasta_dict):
        print("Writing data in single_otu_file.csv... Please wait...")
        GC = lambda seq : [seq, str((seq.count('G')+seq.count('C'))*100/len(seq))]
        try:
            cols=sorted(cols)
            with open("single_otu_file.csv",'w') as f:
                if fasta_dict:
                    f.write('#OTU ID,'+','.join(cols)+',Taxa,Seq,GC\n')
                    cols_dict=dict((name,val) for val,name in enumerate(cols))
                    for x in stack:
                        zeros=['0']*len(cols)
                        denovo,sample,count=x
                        zeros[cols_dict[sample]]=str(count)
                        f.write(','.join( [denovo] + zeros + [taxa_dict[denovo]] + GC(fasta_dict[denovo]) )+'\n')
                else:
                    f.write('#OTU ID,'+','.join(cols)+',Taxa\n')
                    cols_dict=dict((name,val) for val,name in enumerate(cols))
                    for x in stack:
                        zeros=['0']*len(cols)
                        denovo,sample,count=x
                        zeros[cols_dict[sample]]=str(count)
                        f.write(','.join([denovo]+zeros+[taxa_dict[denovo]])+'\n')
            return True
        except Exception as e: print("Some Error while writing data in .csv file\n%s\n%s"%(e,e.__doc__))
        return False
    
    try:
        stack,cols,status = parse_otu(otu_file)
        taxa_dict =False
        if status and taxa_file: taxa_dict, status = make_dictionary(taxa_file)
        if status : fasta_dict = read_fasta(fasta_file)
        if status: status = dump(stack, taxa_dict, cols, fasta_dict)
        if status: print("OTU table created successfully.")
        else: print("Process terminated before completion")
    except: print("Process terminated before completion")
    return 'single_otu_file.csv'

def single_otu_filter(otu_table):
    try:
        print("Filtering Single OTU Occurences...")
        with open(otu_table) as f: lines = f.readlines()
        taxa_col = lines[0].strip('\n').split(',').index('Taxa')
        with open("unique_otu_table.csv",'w') as f:
            f.write(lines[0])
            for line in lines[1:]:
                counts = line.split(',')[1:taxa_col]
                if len(counts) - counts.count('0') == 1: f.write(line)
        print("Single OTU filteration complete...")
        return "unique_otu_table.csv"
    except Exception as e: print(e)
    #return lines

if __name__=='__main__':
    with open("index.txt") as f: index = f.readlines()
    index = dict(line.strip('\n').split(' : ') for line in index)
    single_otu_filter('otu_table.csv')
    input("\nPress <ENTER> to exit.")
