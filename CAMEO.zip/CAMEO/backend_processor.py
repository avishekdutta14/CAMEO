import pickle, os, shutil, zipfile
from lib import *
from time import time, sleep
from subprocess import check_output

"""
from .rarefaction3 import rarefaction
from .single_otu_table3 import single_otu_table
from .otu_table3 import otu_table
from .visualisation3 import visualize
"""

def folder_exists(folder):
    try:
        os.listdir(folder)
        return True
    except: return False

def Server_Address():
    output=check_output(['ipconfig']).decode().split('\n')
    ip = '127.0.0.1'
    for line in output:
        if line[:39]=='   IPv4 Address. . . . . . . . . . . : ':
            ip=line.split(': ')[1].strip('\r')
            print('Host IP : %s\n\n' % ip)
            break
    return ip

def analyze(folder, online = True):
    def ZIP(files):
        os.mkdir('download')
        print("Zipping...")
        for x in files: shutil.copyfile(x,'download/'+x)
        shutil.copytree('files','download/files')
        shutil.make_archive('download_zip','zip', 'download')
        shutil.rmtree('download')
        for x in files:
            if x.split('.')[-1].lower()!='html' : os.remove(x)
        print('Zipping complete...')
        return True

    def prepro():
        EXTRACT = lambda name: zipfile.ZipFile(name).extractall()
        sub = os.listdir()
        print("Extracting files...")
        EXTRACT([r for r in sub if zipfile.is_zipfile(r)][0])
        pre = os.listdir()
        return pre, sub
        
    try:
        if online: email = data[folder][0]
        else: email = 'Offline folder'
        print('Processing: %s'%email)
        try: shutil.copytree('files', folder+'/files')
        except: pass
        os.chdir(folder)
        pre, sub = prepro()
        with open("index.txt") as f: index = f.readlines()
        index = dict(line.strip('\n').split(' : ') for line in index)
        table = otu_table(index['OTU'], index['TAXA'], index['FASTA'], index['CONTROL'])
        compare(table, index['COMPARE'])
        visualize(table, 'common_OTU.html', True)
        try: rarefaction(table, int(index['RARESTP']))
        except: print("Rarefaction FAILED!")
        single_otu_table = single_otu_filter(table)
        visualize(single_otu_table, 'single_OTU.html')
        files = [x for x in os.listdir() if x not in pre]
        try: ZIP(files)
        except: print("Zipping Failed!")
        for x in pre:
            if x not in sub:
                try: os.remove(x)
                except: pass
        os.chdir('../')
        if online:
            with open("completed",'a') as f: f.write(folder+',')
            PostMan(email, "EMGL Analysis", "Dear Sir/Madam,\nThe analysis of your data is finished.\nPlease visit http://%s/%s folder for results.\nRegards"%
                           (Server_Address(),folder))
        print('\n\n')
        return True
    except Exception as e: print(e, e.__doc__)

def check(pending):
    for utime, folder in pending:
        if folder_exists(folder) == False:
            with open("completed",'a') as f: f.write(folder+',')
            pending.remove((utime, folder))
            return pending
        if 'index.txt' in os.listdir(folder):
            status = analyze(folder)
            if status : pending.remove((utime, folder))
        else:
            print("\rWaiting for upload... [%d mins left]  "%((start+1800 - time())//60), end='')
            sleep(30)
    return pending

if __name__ == '__main__':
    start = time()
    print("Working...\n\n")
    with open('completed') as f: completed = f.read().split(',')
    with open("register",'rb') as f: data = pickle.loads(f.read())
    if 'index.txt' in os.listdir('offline'): status = analyze('offline', False)
    pending = []
    for x in data.keys():
        if x not in completed: pending.append((data[x][1], x))
    while len(pending)>0 and time() - start < 1800: pending = check(sorted(pending))
    input("\n\n...")
